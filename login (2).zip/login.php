<?php 

session_start();
$mail = $_POST['address'];
$dsn = "mysql:host=localhost; dbname=tb220242db; charset=utf8";
$user = "tb-220242";
$password = "N95N7ba6UV";
try {
    $dbh = new PDO($dsn, $user, $password);
} catch (PDOException $e) {
    $msg = $e->getMessage();
}

$sql = "SELECT * FROM login30 WHERE mail = :mail";
$stmt = $dbh->prepare($sql);
$stmt->bindValue(':mail', $mail);
$stmt->execute();
$member = $stmt->fetch();
//指定したハッシュがパスワードにマッチしているかチェック
if ($_POST['password']==$member['pass']) {
    //DBのユーザー情報をセッションに保存
    $_SESSION['mail'] = $member['mail'];
    $_SESSION['name'] = $member['name'];
    $msg = 'ログインしました。';
    $link = '<a href="home.php">ホーム</a>';
} else {
    $msg = 'メールアドレスもしくはパスワードが間違っています。';
    $link = '<a href="login.php">戻る</a>';
}
?>

<h1><?php echo $msg; ?></h1>
<?php echo $link; ?>
<?php
   // エラーメッセージの初期化 
   $errorMessage = ""; 
   //ログインボタンが押された場合 
      if(isset($_POST["login"])) { 
      // 1. ユーザIDの入力チェック 
      if (empty($_POST["address"])) {  // emptyは値が空のとき 
          $errorMessage = 'ユーザーIDが未入力です。'; 
      } else if (empty($_POST["password"])) { 
          $errorMessage = 'パスワードが未入力です。'; 
      } 
      }

 ?>

<!doctype html> 
<html> 
    <head> 
            <meta charset="UTF-8"> 
            <title>ログイン</title> 
    </head> 
    <body> 
        <h1>ログイン</h1> 
        <form action="" method="POST"> 
            <fieldset> 
                <legend>ログインフォーム</legend> 
                <div><font color="#ff0000"><?php echo htmlspecialchars($errorMessage, ENT_QUOTES); ?></font></div> 
                <label for="address">ユーザーID</label> 
                <input type="text" name="address" placeholder="メールアドレスを入力" value="<?php if (!empty($_POST["address"]))  
                {echo htmlspecialchars($_POST["address"],ENT_QUOTES);} ?>"> 
                <br> 
                <label for="password">パスワード</label>
                <input type="password" name="password" value="" placeholder="パスワードを入力"> 
                <br> 
                <input type="submit" name="login" value="ログイン"> 
                <p>新規の方は
                <a href="nosub.php">こちら</a>
                </p> 
            </fieldset>
        </form> 
    </body> 
</html>